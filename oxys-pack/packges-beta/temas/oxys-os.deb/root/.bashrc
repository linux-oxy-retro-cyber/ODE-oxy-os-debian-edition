# ~/.bashrc: executed by bash(1) for non-login shells.

# Note: PS1 and umask are already set in /etc/profile. You should not
# need this unless you want different defaults for root.
# PS1='${debian_chroot:+($debian_chroot)}\h:\w\$ '
# umask 022

# You may uncomment the following lines if you want `ls' to be colorized:
# export LS_OPTIONS='--color=auto'
# eval "$(dircolors)"
# alias ls='ls $LS_OPTIONS'
# alias ll='ls $LS_OPTIONS -l'
# alias l='ls $LS_OPTIONS -lA'
#
# Some more alias to avoid making mistakes:
# alias rm='rm -i'
# alias cp='cp -i'
# alias mv='mv -i'

# ==================================================================
#                    ALIASES EXCLUSIVOS DO OXYS OS
# ==================================================================

# 1. Atualiza repositórios, atualiza apps e limpa pacotes velhos (Tudo em um comando só)
alias oxys-update="apt update && apt upgrade -y && apt autoremove -y"

# 2. Comando rápido para compilar e rodar um código C direto usando o seu TCC
alias oxys-run="tcc -run"

# 3. Abre o arquivo de configurações do sistema direto no editor para você criar mais coisas
alias oxys-config="nano /root/.bashrc"

# 4. Atalho para limpar a tela e mostrar o seu Fastfetch customizado com o X verde
alias oxys-info="clear && fastfetch"

